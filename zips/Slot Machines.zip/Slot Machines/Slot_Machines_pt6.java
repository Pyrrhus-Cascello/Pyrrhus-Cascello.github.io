//Pyrrhus
//17/05/2017
// The "Slot_Machines_pt6" class.



import java.awt.*;
import hsa.Console;

public class Slot_Machines_pt6
{
    static Console c;           // The output console

    public static void main (String[] args)
    {
	c = new Console ();

	int fruit1, fruit2, fruit3, vaildBet = 0, fruitCombo = 000;  //fruit1,2,3 are for the random number selection then displaying it on the screen  |  vaildBet is for making sure the users bet is vaild (beting more then they have)  | fruitCombo is to see what kind of winnings the user gets
	double money = 10, bet = 0, loss = 0, gain = 0, made; //money is how money the user has to bet | bet is for how much money they are betting | loss is to see how much they loss | gain is to see how much they gain  | made is for the user to see how much they made at the end
	char tryAgain = 'y';  // loops the game intell the player wants it to stop y meaning yes and n meaning no

	while (tryAgain == 'y')
	{

	    while (vaildBet == 0)
	    {
		c.setCursor (17, 41);
		c.println ("money $" + money); //display users cash
		c.setCursor (18, 41);
		c.println ("gain $" + gain);  //display users money gained
		c.setCursor (19, 41);
		c.println ("loss $" + loss);  //display users money lost

		c.setCursor (17, 15);
		c.print ("How much do you");
		c.setCursor (18, 15);
		c.print ("want to bet : ");
		c.setCursor (19, 15);
		c.print ("Enter 0 for menu");
		c.setCursor (18, 27);
		//making sure the users bet is vaild


		mainMachine ();
		bet = c.readDouble ();

		if ((bet <= money) && (bet > 0)) //making sure the user bets the right amount
		{
		    money = money - bet;
		    loss = loss + bet;
		    vaildBet = 1;
		    c.setCursor (18, 41);
		    c.println ("gain $" + gain);  //display users money gained
		    mainMachine ();
		    armMovement ();
		    wheelSpin ();
		    c.clear ();
		}

		else if (bet == 0)    //it goes to the menu when the user says 0
		{
		    c.setCursor (18, 41);
		    c.println ("gain $" + gain);  //display users money gained
		    mainMachine ();
		    mainMenu ();
		}

		else
		{
		    c.clear ();      //just clears the screen if the user can't get it right and they gotta try again
		}
	    }
	    vaildBet = 0;   // resets the vaildBet for next time

	    //gets random numbers for the fruits1,2,3
	    fruit1 = (int) (Math.random () * (3 - 1 + 1) + 1);
	    fruit3 = (int) (Math.random () * (3 - 1 + 1) + 1);
	    fruit2 = (int) (Math.random () * (3 - 1 + 1) + 1);
	    /*
			fruit1 = 1;
			fruit2 = 3;         //Quick way to test the code
			fruit3 = 1;
	    */
	    //getting and giving the users infomation

	    //this section will check what number they got for fruit 1,2,3 and displaying the proper fruit on the screen
	    if (fruit1 == 1)
	    {
		//drawing cherry

		c.setColor (Color.red);
		c.fillOval (135, 225, 25, 25);
		c.fillOval (110, 225, 25, 25);

		c.setColor (Color.green);
		c.drawLine (122, 224, 135, 200);
		c.drawLine (147, 224, 130, 190);

		fruitCombo = fruitCombo + 100; //setting the value of the possible win   cherrys add 100 oranges add 10 and limes add 1
	    }
	    else if (fruit1 == 2)
	    {
		c.setColor (Color.orange);
		c.fillOval (113, 200, 50, 50);
		//c.fillOval(125,195,15,15); //for version 1 orange

		c.setColor (Color.green);
		//c.fillMapleLeaf(137,202,-10,-10); //for version 1 orange
		c.fillMapleLeaf (145, 210, -16, -16); // comment this line if wanna see version 1

		fruitCombo = fruitCombo + 10;
	    }
	    else if (fruit1 == 3)
	    {
		//lime box 1

		c.setColor (Color.green);
		c.fillOval (113, 200, 50, 35);

		c.fillOval (107, 210, 15, 15);

		c.fillOval (154, 210, 15, 15);

		fruitCombo = fruitCombo + 1;
	    }

	    if (fruit2 == 1)
	    {
		//cherry box 2

		c.setColor (Color.red);
		c.fillOval (270, 225, 25, 25);
		c.fillOval (245, 225, 25, 25);

		c.setColor (Color.green);
		c.drawLine (257, 224, 270, 200);
		c.drawLine (282, 224, 265, 190);
		fruitCombo = fruitCombo + 100;
	    }
	    else if (fruit2 == 2)
	    {
		//orange box 2

		c.setColor (Color.orange);
		c.fillOval (247, 200, 50, 50);

		c.setColor (Color.green);
		c.fillMapleLeaf (280, 210, -16, -16);

		fruitCombo = fruitCombo + 10;
	    }
	    else if (fruit2 == 3)
	    {
		//lime box 2

		c.setColor (Color.green);
		c.fillOval (248, 200, 50, 35);

		c.fillOval (242, 210, 15, 15);

		c.fillOval (289, 210, 15, 15);
		fruitCombo = fruitCombo + 1;
	    }

	    if (fruit3 == 1)
	    {
		//cherry box 3

		c.setColor (Color.red);
		c.fillOval (405, 225, 25, 25);
		c.fillOval (380, 225, 25, 25);

		c.setColor (Color.green);
		c.drawLine (392, 224, 405, 200);
		c.drawLine (417, 224, 400, 190);

		fruitCombo = fruitCombo + 100;
	    }
	    else if (fruit3 == 2)
	    {
		//orange box 3

		c.setColor (Color.orange);
		c.fillOval (383, 200, 50, 50);

		c.setColor (Color.green);
		c.fillMapleLeaf (415, 210, -16, -16);

		fruitCombo = fruitCombo + 10;
	    }
	    else if (fruit3 == 3)
	    {
		//lime box 3

		c.setColor (Color.green);
		c.fillOval (383, 200, 50, 35);

		c.fillOval (377, 210, 15, 15);

		c.fillOval (424, 210, 15, 15);

		fruitCombo = fruitCombo + 1;
	    }


	    c.setTextColor (Color.black);  //honestly I don't remeber I think was it was there when I had the fruit as text and i just forgot to delete when I made it to images but best to leave it since the code works fine with it there


	    //this section is my soultion deciding what award the user gets. instead of doing the longer way of typing all they possible combos for the fruits to be in.
	    //I just made it so cherry equals 100 orange equals 10 and lime equals 1 . so no matter what box the two cherrys are in and on orange/lime is always be 210 or 201

	    if (fruitCombo == 300)
	    {
		c.setCursor (17, 15);
		c.println ("you won $" + bet * 10);
		gain = gain + bet * 10;
		money = money + (bet * 10);

	    }

	    else if (fruitCombo == 30)
	    {
		c.setCursor (17, 15);
		c.println ("you won $" + bet * 5);
		gain = gain + bet * 5;
		money = money + (bet * 5);

	    }

	    else if (fruitCombo == 3)
	    {
		c.setCursor (17, 15);
		c.println ("you won $" + bet * 2);
		gain = gain + bet * 2;
		money = money + (bet * 2);

	    }

	    else if (fruitCombo == 210)
	    {
		c.setCursor (17, 15);
		c.println ("you won $" + bet * 1);
		gain = gain + bet * 1;
		money = money + (bet * 1);

	    }

	    else if (fruitCombo == 201)
	    {
		c.setCursor (17, 15);
		c.println ("you won $" + bet * .5);
		gain = gain + bet * .5;
		money = money + (bet * .5);

	    }
	    else
	    {
		//this is the part of code the user gets if they won nothing and sees if they still have money or not
		if (money > 0)

		    {
			c.setCursor (17, 15);
			c.println ("you won nothing.");
		    }
		else if (money <= 0)
		{
		    c.setCursor (17, 15);
		    c.println ("YOU LOST EVERYTHING ");
		    c.setCursor (18, 15);
		    c.println (" NOW GET OUT!");
		}
	    }

	    if (money > 0)

		{


		    c.setCursor (18, 15);
		    c.println ("Try again? (y/n)");

		    c.setCursor (17, 41);
		    c.println ("money $" + money); //display users cash
		    c.setCursor (18, 41);
		    c.println ("gain $" + gain);  //display users money gained
		    c.setCursor (19, 41);
		    c.println ("loss $" + loss);  //display users money lost


		    mainMachine ();
		    c.setCursor (19, 15);
		    tryAgain = c.readChar ();

		    c.clear ();
		}
	    else if (money <= 0)
	    {
		//I thought it would be fun to put his part in if they had no more money left
		c.setCursor (17, 41);
		c.println ("money $" + money); //display users cash
		c.setCursor (18, 41);
		c.println ("gain $" + gain);  //display users money gained
		c.setCursor (19, 41);
		c.println ("loss $" + loss);  //display users money lost


		c.setCursor (19, 15);
		c.print ("Try again? (y/n) ");  //either way the user doesnt get to play again
		mainMachine ();
		tryAgain = c.readChar ();
		c.clear ();
		if (tryAgain == 'y')  //if the user really thinks they can play with out money they get this
		{
		    c.setCursor (17, 15);

		    c.println ("DON'T push me kid.");
		    mainMachine ();
		    tryAgain = 'n';
		}

	    }
	    fruitCombo = 0;  //reseting the fruitCombo for next go around

	}

	//this delay is not a method since im only using it once
	try
	{
	    Thread.sleep (1000);
	}
	catch (Exception e)    //I dont know what this does i just need it for the timer to work
	{

	}
	c.clear ();
	c.println ("Thank you for play SCOTTY SLAUGHT'S SLOTS slots");
	c.println ("You ended with $" + money);
	c.println ("You lossed $" + loss);
	c.println ("You gained $" + gain);
	made = gain - loss;
	c.println ("In total you made $" + made);



	// Place your program here.  'c' is the output console
    } // main method


    public static void mainMachine ()
    {

	//the graphics for the machine
	//Main body
	c.setColor (Color.blue);
	c.fillOval (50, 10, 75, 75);
	c.fillOval (425, 10, 75, 75);
	c.fillRect (90, 10, 370, 40);
	c.fillRect (50, 50, 450, 75);

	c.fillRect (50, 125, 25, 175);
	c.fillRect (475, 125, 25, 175);

	c.fillRect (200, 125, 6, 175);
	c.fillRect (334, 125, 6, 175);

	c.fillRect (50, 300, 450, 20);

	c.fillRect (300, 320, 20, 60);
	c.fillRect (50, 320, 50, 60);

	c.fillRect (320, 320, 180, 2);
	c.fillRect (320, 336, 180, 6);
	c.fillRect (320, 356, 180, 6);
	c.fillRect (320, 376, 180, 6);

	c.fillRect (420, 320, 80, 179);

	c.fillRect (50, 380, 100, 179);
	c.fillRect (220, 380, 280, 179);

	// c.fillRect (150, 380, 70, 5);  //there if i can figure out to change how typing text works but probably cant
	c.fillRect (150, 380, 70, 20);    // for if i can figure out above
	c.fillRect (150, 399, 70, 101);

	//arm
	c.setColor (Color.blue);
	c.fillRect (500, 195, 50, 20);
	c.fillRect (540, 70, 10, 130);
	c.setColor (Color.black);
	c.fillRect (500, 180, 10, 50);
	c.fillOval (532, 50, 25, 25);

    } //mainMachine method


    public static void armMovement ()

    {
	//graphics for the machine's arm to go down and up
	c.setColor (Color.blue);
	c.fillRect (500, 195, 50, 20); //side to side arm that plugs to block
	c.fillRect (540, 70, 10, 130);  // up and down arm
	c.setColor (Color.black);
	c.fillRect (500, 180, 10, 50); //block
	c.fillOval (532, 50, 25, 25); //ball handle

	delay250 ();

	//earse
	c.setColor (Color.white);
	c.fillRect (540, 70, 10, 125);
	c.fillOval (532, 50, 25, 25);


	c.setColor (Color.blue);
	c.fillRect (540, 120, 10, 80);  // up and down arm
	c.setColor (Color.black);
	c.fillOval (532, 100, 25, 25); //ball handle

	delay250 ();

	//earse
	c.setColor (Color.white);
	c.fillRect (540, 120, 10, 75);
	c.fillOval (532, 100, 25, 25);


	c.setColor (Color.blue);
	c.fillRect (540, 170, 10, 25);  // up and down arm
	c.setColor (Color.black);
	c.fillOval (532, 150, 25, 25); //ball handle

	delay250 ();

	//earse
	c.setColor (Color.white);
	c.fillRect (540, 170, 10, 25);
	c.fillOval (532, 150, 25, 25);

	c.setColor (Color.black);
	c.fillOval (532, 193, 25, 25); //ball handle

	delay250 ();

	//earse
	c.setColor (Color.white);
	c.fillOval (532, 193, 25, 25);
	c.setColor (Color.blue);
	c.fillRect (510, 195, 40, 20); //side to side arm


	c.setColor (Color.blue);
	c.fillRect (540, 170, 10, 25);  // up and down arm
	c.setColor (Color.black);
	c.fillOval (532, 150, 25, 25); //ball handle


	delay250 ();

	//earse
	c.setColor (Color.white);
	c.fillRect (540, 170, 10, 25);
	c.fillOval (532, 150, 25, 25);

	c.setColor (Color.blue);
	c.fillRect (540, 120, 10, 80);  // up and down arm
	c.setColor (Color.black);
	c.fillOval (532, 100, 25, 25); //ball handle

	delay250 ();

	//earse
	c.setColor (Color.white);
	c.fillRect (540, 120, 10, 75);
	c.fillOval (532, 100, 25, 25);


	c.setColor (Color.blue);
	c.fillRect (500, 195, 50, 20); //side to side arm that plugs to block
	c.fillRect (540, 70, 10, 130);  // up and down arm
	c.setColor (Color.black);
	c.fillRect (500, 180, 10, 50); //block
	c.fillOval (532, 50, 25, 25); //ball handle

    } //armMovement method


    public static void wheelSpin ()
    {
	//grapics to make the wheel look like its spinning
	for (int i = 0 ; i < 8 ; i++)  //reapting the spin 8 times
	{
	    c.setColor (Color.white);
	    c.fillRect (75, 125, 125, 175); //clear box one

	    //cherry
	    c.setColor (Color.red);
	    c.fillOval (135, 225, 25, 25);
	    c.fillOval (110, 225, 25, 25);

	    c.setColor (Color.green);
	    c.drawLine (122, 224, 135, 200);
	    c.drawLine (147, 224, 130, 190);

	    delay20 ();
	    c.setColor (Color.white);
	    c.fillRect (206, 125, 128, 175);   //clear box two

	    //lime
	    c.setColor (Color.green);
	    c.fillOval (248, 200, 50, 35);
	    c.fillOval (242, 210, 15, 15);
	    c.fillOval (289, 210, 15, 15);

	    delay20 ();
	    c.setColor (Color.white);
	    c.fillRect (340, 125, 135, 175);   //clear box three

	    //orange
	    c.setColor (Color.orange);
	    c.fillOval (383, 200, 50, 50);
	    c.setColor (Color.green);
	    c.fillMapleLeaf (415, 210, -16, -16);

	    delay20 ();
	    c.setColor (Color.white);
	    c.fillRect (75, 125, 125, 175); //clear box one

	    //orange
	    c.setColor (Color.orange);
	    c.fillOval (113, 200, 50, 50);
	    c.setColor (Color.green);
	    c.fillMapleLeaf (145, 210, -16, -16);

	    delay20 ();
	    c.setColor (Color.white);
	    c.fillRect (206, 125, 128, 175);   //clear box two

	    //cherry
	    c.setColor (Color.red);
	    c.fillOval (270, 225, 25, 25);
	    c.fillOval (245, 225, 25, 25);

	    c.setColor (Color.green);
	    c.drawLine (257, 224, 270, 200);
	    c.drawLine (282, 224, 265, 190);

	    delay20 ();
	    c.setColor (Color.white);
	    c.fillRect (340, 125, 135, 175);   //clear box three

	    //lime
	    c.setColor (Color.green);
	    c.fillOval (383, 200, 50, 35);
	    c.fillOval (377, 210, 15, 15);
	    c.fillOval (424, 210, 15, 15);

	    delay20 ();
	    c.setColor (Color.white);
	    c.fillRect (75, 125, 125, 175); //clear box one


	    //lime
	    c.setColor (Color.green);
	    c.fillOval (113, 200, 50, 35);
	    c.fillOval (107, 210, 15, 15);
	    c.fillOval (154, 210, 15, 15);

	    delay20 ();
	    c.setColor (Color.white);
	    c.fillRect (206, 125, 128, 175);   //clear box two


	    //orange
	    c.setColor (Color.orange);
	    c.fillOval (247, 200, 50, 50);

	    c.setColor (Color.green);
	    c.fillMapleLeaf (280, 210, -16, -16);

	    delay20 ();
	    c.setColor (Color.white);
	    c.fillRect (340, 125, 135, 175);   //clear box three

	    //cherry
	    c.setColor (Color.red);
	    c.fillOval (405, 225, 25, 25);
	    c.fillOval (380, 225, 25, 25);

	    c.setColor (Color.green);
	    c.drawLine (392, 224, 405, 200);
	    c.drawLine (417, 224, 400, 190);

	    delay20 ();
	    //final wipe for the real combo the user will get
	    c.setColor (Color.white);
	    //locationof wheel one
	    c.fillRect (75, 125, 125, 175);
	    //locationofwheel two
	    c.fillRect (206, 125, 128, 175);
	    //locationofwheel three
	    c.fillRect (340, 125, 135, 175);

	}
    } //wheelSpin method


    public static void mainMenu ()
    {

	int menu = 1;
	//code for the drop menu. I made it a while loop incase I decide to add more options to it and if the user choices unavabile choice it doesnt go back to the game of course some minor tweeks would be needed
	while (menu == 1)

	    {
		c.setTextBackgroundColor (Color.lightGray);
		c.setCursor (1, 1);
		delay400 ();
		c.setTextColor (Color.red);
		c.print ("  3 Cherries");
		c.setTextColor (Color.black);
		c.println ("            | 10x bet  ");

		delay400 ();
		c.setTextColor (Color.orange);
		c.print ("  3 Oranges");
		c.setTextColor (Color.black);
		c.println ("             | 5x bet  ");

		delay400 ();
		c.setTextColor (Color.green);
		c.print ("  3 Limes");
		c.setTextColor (Color.black);
		c.println ("              | 2x bet  ");

		delay400 ();
		c.setTextColor (Color.red);
		c.print ("  2 Cherries");
		c.setTextColor (Color.orange);
		c.print ("  1 Orange");
		c.setTextColor (Color.black);
		c.println ("  | 1x bet ");

		delay400 ();
		c.setTextColor (Color.red);
		c.print ("  2 Cherries");
		c.setTextColor (Color.green);
		c.print ("  1 Lime");
		c.setTextColor (Color.black);
		c.println ("  | .5x bet  ");

		delay400 ();
		c.print ("Enter 0 to go back to game :                                                    "); //the big space is there so the grey text back ground goes accross the whole screen

		c.setCursor (6, 29);
		menu = c.readInt ();

	    }
	c.setTextBackgroundColor (Color.white); //reseting the color back to white but if it was before the clear screen it would make the whole screen turn that colour
	c.clear ();

    } // mainMenu method


    //Reset of these are just code to delay the program the method name is pretty simple too delay meaning its a delay the number is for how long

    public static void delay250 ()
    {
	try
	{
	    Thread.sleep (250);
	}
	catch (Exception e)    //I dont know what this does i just need it for the timer to work
	{

	}

    } //delay500 method


    public static void delay20 ()
    {
	try
	{
	    Thread.sleep (20);
	}
	catch (Exception e)    //I dont know what this does i just need it for the timer to work
	{

	}

    } //delay20 method


    public static void delay400 ()
    {
	try
	{
	    Thread.sleep (400);
	}
	catch (Exception e)    //I dont know what this does i just need it for the timer to work
	{
	}
    } //delay400 method
} // Slot_Machines_pt1 class


